import React, { useState } from "react";
import {
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  FormGroup,
  FormControlLabel,
  Box,
  Card,
  CardContent,
  CardMedia,
  Typography,
  IconButton,
  Button,
} from "@mui/material";
import { HashLoader } from "react-spinners";
import CircularProgress from "@mui/material/CircularProgress";
import FavoriteOutlinedIcon from "@mui/icons-material/FavoriteOutlined";
import HouseModal from "../components/HouseModal";
import { UserAuth } from "../context/AuthContext";
import { HouseAuth } from "../context/HouseContext";
import { useEffect } from "react";
import useMainStore from "../components/store/mainStore";

function Houses() {
  const { user, logout } = UserAuth();
  const { getAllHouses, toggleHouseInFavorites } = HouseAuth();
  const [houses, setHouses] = useState([]); // Store fetched houses here
  const [currentPage, setCurrentPage] = useState(0);
  const [pageData, setPageData] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [subcity, setSubcity] = useState("");
  const [rooms, setRooms] = useState("");
  const [price, setPrice] = useState("");
  const [privateBathroom, setPrivateBathroom] = useState(false);
  const [nextpageCheck, setNextpageCheck] = useState(true);

  const [selectedHouseData, setSelectedHouseData] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const totalPages = useMainStore((state) => state.totalHousePages);
  const storedUserData = useMainStore((state) => state.userData);
  const [lastDocumentSnapshot, setLastDocumentSnapshot] = useState(null);
  const subcities = [
    "Arada",
    "Addis Ketema",
    "Bole",
    "Gullele",
    "Kirkos",
    "Kolfe Keranio",
    "Lideta",
    "Nifas Silk-Lafto",
    "Yeka",
  ];
  const PAGE_SIZE = 10; // Number of houses per page

  // Function to open the modal and set the selected house data
  const openModal = (houseData) => {
    setSelectedHouseData(houseData);
    setModalOpen(true);
  };

  // Function to close the modal
  const closeModal = () => {
    setSelectedHouseData(null);
    setModalOpen(false);
  };

  // Fetch houses for the next page using the last timestamp
  const fetchPage = async () => {
    setIsLoading(true);
    try {
      const {
        houses: newHouses,
        hasNextPage,
        lastDocumentSnapshot: newLastDocumentSnapshot,
      } = await getAllHouses(
        PAGE_SIZE,
        lastDocumentSnapshot,
        subcity,
        rooms,
        price
      );

      // Update the lastDocumentSnapshot
      setLastDocumentSnapshot(newLastDocumentSnapshot);

      // Update the pageData dictionary with the new page data
      setPageData((prevData) => ({
        ...prevData,
        [currentPage]: newHouses,
      }));

      setHouses(newHouses);
      setCurrentPage(currentPage + 1);

      if (!hasNextPage) {
        // Handle logic when there are no more pages
        setNextpageCheck(false);
      }
      setIsLoading(false);
    } catch (error) {
      console.error("Error fetching next page:", error);
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Reset the pagination state
    setHouses([]);
    setLastDocumentSnapshot(null);
    setCurrentPage(1);
    setPageData([]);
    setNextpageCheck(true);
  }, [subcity, rooms, price]);

  useEffect(() => {
    if (lastDocumentSnapshot === null) {
      // Now that we know it's null, fetch the first page
      fetchPage();
    }
  }, [lastDocumentSnapshot]);
  console.log("page data first : ", pageData);

  // Handle Next Page button click
  const handleNextPage = () => {
    // Count the number of pages stored in pageData
    let pageCount = 0;

    if (pageData) {
      pageCount = Object.keys(pageData).length;
    }
    if (pageCount > currentPage) {
      setHouses(pageData[currentPage]);
      setCurrentPage(currentPage + 1);
    } else if (nextpageCheck) {
      if (houses.length > 0) {
        const lastHouse = houses[houses.length - 1];
        const lastTimestamp = lastHouse.timestamp; // "timestamp" is the field to order by
        fetchPage(lastTimestamp);
      }
    }
  };
  // Handle Previous Page button click
  const handlePreviousPage = () => {
    // Count the number of pages stored in pageData
    let pageCount = 0;
    if (pageData) {
      pageCount = Object.keys(pageData).length;
    }
    if (pageCount > 1) {
      const previousDataIndex = currentPage - 2;

      // Check if the previous page exists in pageData
      if (pageData[previousDataIndex]) {
        setHouses(pageData[previousDataIndex]);
        setCurrentPage(currentPage - 1);
      } else {
        console.log(`Page ${previousDataIndex} data not found`);
      }
    }
  };

  const handleToggleFavorites = async (userId, houseId) => {
    try {
      const updatedUser = { ...storedUserData }; // Create a copy of the user data

      // Toggle the houseId in the favorites array
      const favoritesIndex = updatedUser?.favorites?.indexOf(houseId);
      if (favoritesIndex !== -1) {
        updatedUser.favorites.splice(favoritesIndex, 1); // Remove from favorites
      } else {
        updatedUser.favorites.push(houseId); // Add to favorites
      }

      // Update the user data in Zustand
      useMainStore.getState().setUserData(updatedUser);
      await toggleHouseInFavorites(userId, houseId);
      console.log("House toggled in favorites successfully.");
    } catch (error) {
      console.error("Error toggling house in favorites:", error);
    }
  };

  const styles = {
    cardContainer: {
      width: { xs: "90%", md: "300px" },
      height: "400px",
      margin: "auto",
      backgroundColor: "white",
      boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
      borderRadius: "8px",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
    },
    cardImage: {
      minHeight: "200px",
      objectFit: "cover",
    },
    cardContent: {
      padding: "16px",
    },
    cardTitle: {
      fontSize: "18px",
      fontWeight: "bold",
      marginBottom: "8px",
    },
    cardText: {
      fontSize: "16px",
      marginBottom: "8px",
    },
    cardActions: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    },
    detailsButton: {
      backgroundColor: "#2D6072",
      color: "white",
    },
  };

  return (
    <Box>
      {/* search field */}
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        gap={2}
        sx={{
          // maxWidth: "700px",
          margin: "0 auto",
          backgroundColor: "#2D6072",
          p: {
            sm: "30px",
          },
          paddingBottom: {
            sm: "30px",
          },
          borderTop: "solid orange 10px",
        }}
      >
        <Box display="flex" gap={2} flexWrap="wrap" width="100%">
          <FormControl
            variant="outlined"
            style={{ flex: 1, backgroundColor: "#f7f7f7" }}
          >
            <InputLabel>Sub-City</InputLabel>
            <Select
              value={subcity}
              onChange={(e) => setSubcity(e.target.value)}
              label="subcity"
              style={{ width: "100%" }}
            >
              <MenuItem value="">
                <em>Any</em>
              </MenuItem>
              {/* Dropdown options */}
              {subcities.map((subcity, index) => (
                <MenuItem key={index} value={subcity}>
                  {subcity}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl
            variant="outlined"
            style={{ flex: 1, backgroundColor: "#f7f7f7" }}
          >
            <InputLabel>Rooms</InputLabel>
            <Select
              value={rooms}
              onChange={(e) => setRooms(e.target.value)}
              label="Rooms"
              style={{ width: "100%" }}
            >
              <MenuItem value="">
                <em>Any</em>
              </MenuItem>
              <MenuItem value="1">1</MenuItem>
              <MenuItem value="2">2</MenuItem>
              <MenuItem value="3">3</MenuItem>
              <MenuItem value="4">4</MenuItem>
              <MenuItem value="5+">5+</MenuItem>
            </Select>
          </FormControl>

          <FormControl
            variant="outlined"
            style={{ flex: 1, backgroundColor: "#f7f7f7" }}
          >
            <InputLabel>Price-Range</InputLabel>
            <Select
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              label="pricerange"
              style={{ width: "100%" }}
            >
              <MenuItem value="">
                <em>Any</em>
              </MenuItem>
              <MenuItem value="1-5000">0 - 5k Birr</MenuItem>
              <MenuItem value="5000-9000">5k - 9k Birr</MenuItem>
              <MenuItem value="9000-15000">9k - 15k Birr</MenuItem>
              <MenuItem value="15000-200000">15k+ Birr</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Box>
      <Box className="spinner-parent">
        {isLoading ? (
          // Loading screen
          <div className="spinner-contained-container">
            <HashLoader color="orange" size={100} />
            <div className="spinner-text">Loading...</div>
          </div>
        ) : houses?.length === 0 ? (
          // Empty data message
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "100vh",
            }}
          >
            <Typography variant="h6">No houses found.</Typography>
          </div>
        ) : (
          // Display favorite houses
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                sm: "1fr 1fr",
                md: "1fr 1fr 1fr 1fr",
              },
              gap: "20px",
              width: "100%",
              marginTop: "20px",
              color: "black",
            }}
          >
            {houses?.map((house) => (
              <Card key={house.id} sx={styles.cardContainer}>
                <CardMedia
                  component="img"
                  height="200"
                  image={house.pic1} // Replace with the actual image URL
                  alt={house.subcity}
                  sx={styles.cardImage}
                />
                <CardContent sx={styles.cardContent}>
                  <Typography variant="h6" sx={styles.cardTitle}>
                    {house.subcity}
                  </Typography>
                  <Typography variant="h6" sx={styles.cardText}>
                    {house.price} Birr
                  </Typography>
                  <Typography variant="h6" sx={styles.cardText}>
                    {house.area}
                  </Typography>
                  <Typography variant="h6" sx={styles.cardText}>
                    {house.rooms} Room
                  </Typography>
                  <Box sx={styles.cardActions}>
                    <IconButton
                      aria-label="Add to favorites"
                      sx={{
                        color: storedUserData?.favorites?.includes(house.id)
                          ? "red"
                          : "gray",
                      }}
                      onClick={() => handleToggleFavorites(user.uid, house.id)}
                    >
                      <FavoriteOutlinedIcon />
                    </IconButton>
                    <Button
                      variant="contained"
                      onClick={() => openModal(house)}
                      sx={styles.detailsButton}
                    >
                      Details
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            ))}
          </Box>
        )}
      </Box>
      <div>
        {/* Modal */}
        <HouseModal
          open={modalOpen}
          onClose={closeModal}
          house={selectedHouseData}
        />
        {/* Previous and Next navigation */}
        <div>
          <Button variant="outlined" onClick={handlePreviousPage}>
            Previous
          </Button>
          <Button variant="outlined" onClick={handleNextPage}>
            Next
          </Button>
        </div>
      </div>
    </Box>
  );
}

export default Houses;
