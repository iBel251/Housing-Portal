import React from "react";
import { Box, Typography, Button, Avatar, Paper } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import ContactMailIcon from "@mui/icons-material/ContactMail";
import HouseIcon from "@mui/icons-material/House";
import BlockIcon from "@mui/icons-material/Block";

const styles = {
  paper: {
    padding: "16px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "16px",
  },
  header: {
    marginBottom: "8px",
  },
  buttons: {
    display: "flex",
    gap: "8px",
    flexWrap: "wrap",
  },
  avatar: {
    width: "100px",
    height: "100px",
  },
};

const UserDetail = ({ user }) => {
  if (!user) return <Box>No user selected</Box>;

  return (
    <Paper elevation={3} sx={styles.paper}>
      <Typography variant="h4" sx={styles.header}>
        User Details:
      </Typography>
      <Typography variant="body1">ID: {user.id}</Typography>
      <Typography variant="body1">First Name: {user.firstName}</Typography>
      <Typography variant="body1">Last Name: {user.lastName}</Typography>
      <Typography variant="body1">House ID: {user.houseId}</Typography>
      <Avatar
        src={user.picUrl}
        alt={`${user.firstName} ${user.lastName}`}
        sx={styles.avatar}
      />
      <Box sx={styles.buttons}>
        <Button
          startIcon={<ContactMailIcon />}
          variant="contained"
          color="primary"
        >
          Contact
        </Button>
        <Button startIcon={<BlockIcon />} variant="contained" color="warning">
          Suspend from Chat
        </Button>
        <Button startIcon={<DeleteIcon />} variant="contained" color="error">
          Delete
        </Button>
        <Button startIcon={<EditIcon />} variant="contained" color="primary">
          Edit
        </Button>
        <Button startIcon={<HouseIcon />} variant="contained">
          House Detail
        </Button>
      </Box>
    </Paper>
  );
};

export default UserDetail;
