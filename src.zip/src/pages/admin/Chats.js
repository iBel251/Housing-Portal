import React from "react";

const Chats = () => {
  return <div>Chats</div>;
};

export default Chats;
